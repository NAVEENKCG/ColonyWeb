import React, { useState } from 'react';
import { Building2, ArrowRight, CheckCircle2, Shield } from 'lucide-react';
import { User, UserRole } from '../types';

interface LoginScreenProps {
  onLoginSuccess: (user: User) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess }) => {
  const [phoneNumber, setPhoneNumber] = useState('9876543210');
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState(['1', '2', '3', '4']);
  const [needsFlatLinking, setNeedsFlatLinking] = useState(false);
  const [flatNumber, setFlatNumber] = useState('B-402');
  const [block, setBlock] = useState('Block B');
  const [name, setName] = useState('Rajendran N.');
  const [selectedRole, setSelectedRole] = useState<UserRole>('resident');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber || phoneNumber.length < 10) {
      setErrorMsg('Please enter a valid 10-digit mobile number.');
      return;
    }
    setErrorMsg('');
    setOtpSent(true);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    const enteredOtp = otpCode.join('');
    if (enteredOtp.length < 4) {
      setErrorMsg('Please enter the 4-digit verification code.');
      return;
    }
    // Simulate first-time user check or proceed
    setNeedsFlatLinking(true);
  };

  const handleCompleteRegistration = (e: React.FormEvent) => {
    e.preventDefault();
    if (!flatNumber.trim()) {
      setErrorMsg('Please enter your flat number.');
      return;
    }

    const newUser: User = {
      id: 'usr-' + Date.now(),
      name: name.trim() || 'Resident',
      phone: phoneNumber,
      flatNumber: flatNumber.trim(),
      block: block.trim() || 'Block B',
      role: selectedRole,
    };

    onLoginSuccess(newUser);
  };

  const handleQuickBypass = (role: UserRole = 'resident') => {
    onLoginSuccess({
      id: 'usr-default',
      name: role === 'committee' ? 'Suresh Kumar (Admin)' : 'Rajendran N.',
      phone: '9876543210',
      flatNumber: 'B-402',
      block: 'Block B',
      role,
    });
  };

  return (
    <div
      id="login-screen"
      className="min-h-screen bg-[#F4F7F6] flex flex-col justify-center items-center px-4 py-12"
    >
      <div className="w-full max-w-sm flex flex-col items-center">
        {/* Brand Icon */}
        <div
          id="brand-logo-icon"
          className="w-16 h-16 bg-[#08424D] rounded-2xl flex items-center justify-center shadow-lg shadow-teal-900/10 mb-4 transition-transform hover:scale-105"
        >
          <Building2 className="w-9 h-9 text-white stroke-[1.75]" />
        </div>

        {/* Title */}
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight text-center">
          Colony Connect
        </h1>
        <p className="text-sm text-slate-600 mt-1 mb-8 text-center font-medium">
          Login to file and track complaints.
        </p>

        {/* Card */}
        <div className="w-full bg-white/90 backdrop-blur-sm border border-slate-100 rounded-3xl p-6 shadow-sm">
          {!otpSent && !needsFlatLinking && (
            <form onSubmit={handleSendOtp} className="space-y-4">
              <div>
                <label
                  htmlFor="phone-input"
                  className="block text-sm font-medium text-slate-700 mb-2"
                >
                  Phone Number / <span className="text-slate-500">தொலைபேசி எண்</span>
                </label>
                <div className="border-2 border-[#08424D] rounded-2xl px-4 py-3.5 flex items-center gap-3 bg-white focus-within:ring-2 focus-within:ring-teal-500/30">
                  <span className="text-base font-bold text-slate-800 tracking-tight">+91</span>
                  <div className="h-5 w-px bg-slate-300"></div>
                  <input
                    id="phone-input"
                    type="tel"
                    maxLength={10}
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                    placeholder="10-digit mobile number"
                    className="w-full text-base text-slate-900 placeholder:text-slate-400 font-medium focus:outline-none bg-transparent"
                    autoFocus
                  />
                </div>
              </div>

              {errorMsg && (
                <p className="text-xs font-semibold text-rose-600">{errorMsg}</p>
              )}

              <button
                id="send-otp-button"
                type="submit"
                className="w-full bg-[#08424D] hover:bg-[#06333c] active:scale-[0.99] text-white py-3.5 px-4 rounded-2xl shadow transition-all flex flex-col items-center justify-center gap-0.5 mt-2 cursor-pointer"
              >
                <span className="text-base font-bold leading-tight">Send OTP</span>
                <span className="text-xs text-teal-100 font-medium leading-tight">ஓடிபி அனுப்புக</span>
              </button>
            </form>
          )}

          {otpSent && !needsFlatLinking && (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-sm font-medium text-slate-700">
                    Enter OTP / <span className="text-slate-500">ஓடிபி எண்</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setOtpSent(false)}
                    className="text-xs text-[#08424D] font-bold underline"
                  >
                    Change Number
                  </button>
                </div>
                <p className="text-xs text-slate-500 mb-3">
                  Code sent to +91 {phoneNumber} (Demo code: 1234)
                </p>

                <div className="flex justify-between gap-2 my-2">
                  {[0, 1, 2, 3].map((index) => (
                    <input
                      key={index}
                      id={`otp-input-${index}`}
                      type="text"
                      maxLength={1}
                      value={otpCode[index] || ''}
                      onChange={(e) => {
                        const newOtp = [...otpCode];
                        newOtp[index] = e.target.value.slice(-1);
                        setOtpCode(newOtp);
                      }}
                      className="w-14 h-14 text-center text-xl font-bold border-2 border-slate-300 focus:border-[#08424D] rounded-xl bg-slate-50 focus:bg-white focus:outline-none"
                    />
                  ))}
                </div>
              </div>

              {errorMsg && (
                <p className="text-xs font-semibold text-rose-600">{errorMsg}</p>
              )}

              <button
                id="verify-otp-button"
                type="submit"
                className="w-full bg-[#08424D] hover:bg-[#06333c] active:scale-[0.99] text-white py-3.5 px-4 rounded-2xl shadow transition-all flex items-center justify-center gap-2 mt-2 cursor-pointer font-bold"
              >
                <span>Verify OTP / சரிபார்க்கவும்</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {needsFlatLinking && (
            <form onSubmit={handleCompleteRegistration} className="space-y-3.5">
              <div className="flex items-center gap-2 text-teal-800 font-bold text-sm mb-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Phone Verified / தொலைபேசி சரிபார்க்கப்பட்டது</span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Full Name / முழு பெயர்
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Rajendran N."
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:border-[#08424D]"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Flat No. / பிளாட்
                  </label>
                  <input
                    type="text"
                    value={flatNumber}
                    onChange={(e) => setFlatNumber(e.target.value)}
                    placeholder="B-402"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:border-[#08424D]"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Block / பிரிவு
                  </label>
                  <input
                    type="text"
                    value={block}
                    onChange={(e) => setBlock(e.target.value)}
                    placeholder="Block B"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:border-[#08424D]"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Account Type / கணக்கு வகை
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedRole('resident')}
                    className={`py-2 px-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 ${
                      selectedRole === 'resident'
                        ? 'border-[#08424D] bg-teal-50 text-[#08424D]'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    Resident / குடியிருப்பு
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedRole('committee')}
                    className={`py-2 px-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 ${
                      selectedRole === 'committee'
                        ? 'border-[#08424D] bg-teal-50 text-[#08424D]'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    <Shield className="w-3.5 h-3.5 text-emerald-600" />
                    Committee / நிர்வாகம்
                  </button>
                </div>
              </div>

              {errorMsg && (
                <p className="text-xs font-semibold text-rose-600">{errorMsg}</p>
              )}

              <button
                id="complete-link-flat-button"
                type="submit"
                className="w-full bg-[#08424D] hover:bg-[#06333c] text-white py-3.5 px-4 rounded-2xl shadow transition-all font-bold text-sm flex items-center justify-center gap-2 mt-2"
              >
                <span>Continue to Dashboard / தொடரவும்</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}
        </div>

        {/* Note Footer */}
        <p className="text-xs text-slate-500 mt-6 text-center leading-relaxed max-w-xs font-medium">
          Note: For first-time users, you will be prompted to link your Flat Number after verification.
        </p>

        {/* Quick Demo Logins for Instant Testing */}
        <div className="mt-8 pt-4 border-t border-slate-200/80 w-full flex flex-col items-center">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            Quick Preview Access
          </span>
          <div className="flex gap-2 w-full">
            <button
              onClick={() => handleQuickBypass('resident')}
              className="flex-1 py-2 px-3 bg-white border border-slate-200 text-[#08424D] rounded-xl text-xs font-bold shadow-sm hover:bg-slate-50"
            >
              Resident View (B-402)
            </button>
            <button
              onClick={() => handleQuickBypass('committee')}
              className="flex-1 py-2 px-3 bg-white border border-slate-200 text-emerald-800 rounded-xl text-xs font-bold shadow-sm hover:bg-slate-50"
            >
              Committee View (Admin)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
