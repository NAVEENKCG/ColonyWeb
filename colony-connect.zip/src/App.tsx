import React, { useState, useEffect } from 'react';
import {
  User,
  UserRole,
  Complaint,
  Notice,
  ActiveTab,
  AppView,
} from './types';
import {
  INITIAL_USER,
  INITIAL_COMPLAINTS,
  INITIAL_NOTICES,
} from './data/initialData';
import { LoginScreen } from './components/LoginScreen';
import { TopHeader } from './components/TopHeader';
import { ResidentHomeScreen } from './components/ResidentHomeScreen';
import { CommitteeDashboardScreen } from './components/CommitteeDashboardScreen';
import { RaiseComplaintScreen } from './components/RaiseComplaintScreen';
import { ComplaintDetailScreen } from './components/ComplaintDetailScreen';
import { NoticesScreen } from './components/NoticesScreen';
import { BottomNavBar } from './components/BottomNavBar';
import { Smartphone, Monitor, Sparkles, CheckCircle2 } from 'lucide-react';

const STORAGE_KEY_USER = 'colony_connect_user_v1';
const STORAGE_KEY_COMPLAINTS = 'colony_connect_complaints_v1';
const STORAGE_KEY_NOTICES = 'colony_connect_notices_v1';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_USER);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_USER;
  });

  const [complaints, setComplaints] = useState<Complaint[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_COMPLAINTS);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_COMPLAINTS;
  });

  const [notices, setNotices] = useState<Notice[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_NOTICES);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_NOTICES;
  });

  const [activeTab, setActiveTab] = useState<ActiveTab>('complaints');
  const [activeView, setActiveView] = useState<AppView>('resident_home');
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isMobileFrameView, setIsMobileFrameView] = useState<boolean>(true);

  // Sync state to local storage
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(STORAGE_KEY_USER);
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_COMPLAINTS, JSON.stringify(complaints));
  }, [complaints]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_NOTICES, JSON.stringify(notices));
  }, [notices]);

  // Adjust default screen when switching tabs
  const handleSelectTab = (tab: ActiveTab) => {
    setActiveTab(tab);
    if (tab === 'complaints') {
      setActiveView(currentUser?.role === 'committee' ? 'committee_dashboard' : 'resident_home');
    } else if (tab === 'raise') {
      setActiveView('raise_complaint');
    } else if (tab === 'notices') {
      setActiveView('notices');
    }
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    setActiveTab('complaints');
    setActiveView(user.role === 'committee' ? 'committee_dashboard' : 'resident_home');
    showToast(`Welcome back, ${user.name}!`);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setActiveView('login');
  };

  const handleSwitchRole = (newRole: UserRole) => {
    if (!currentUser) return;
    const updated = { ...currentUser, role: newRole };
    setCurrentUser(updated);
    if (activeTab === 'complaints') {
      setActiveView(newRole === 'committee' ? 'committee_dashboard' : 'resident_home');
    }
    showToast(`Switched to ${newRole === 'committee' ? 'Committee Management' : 'Resident'} view`);
  };

  const handleCreateComplaint = (
    newComplaintData: Omit<Complaint, 'id' | 'customId' | 'reportedAt' | 'timeline'>
  ) => {
    const idNum = Math.floor(1000 + Math.random() * 9000);
    const newId = `CMP-${idNum}`;
    const now = new Date();
    const timeFormatted = `Today, ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    const newComplaint: Complaint = {
      ...newComplaintData,
      id: 'cmp-' + Date.now(),
      customId: newId,
      reportedAt: timeFormatted,
      timeline: [
        {
          id: 'tl-' + Date.now(),
          senderType: 'user',
          senderName: currentUser?.name || 'You',
          senderNameTa: 'நீங்கள்',
          timestamp: timeFormatted,
          text: newComplaintData.description,
          textTa: newComplaintData.descriptionTa,
          photoUrl: newComplaintData.photoUrl,
        },
      ],
    };

    setComplaints([newComplaint, ...complaints]);
    setSelectedComplaint(newComplaint);
    setActiveView('complaint_detail');
    showToast('Complaint registered successfully! (புகார் பதிவு செய்யப்பட்டது)');
  };

  const handleUpdateComplaint = (updatedComplaint: Complaint) => {
    setComplaints(complaints.map((c) => (c.id === updatedComplaint.id ? updatedComplaint : c)));
    setSelectedComplaint(updatedComplaint);
    showToast('Complaint updated successfully.');
  };

  const handleAddNotice = (newNoticeData: Omit<Notice, 'id'>) => {
    const newNotice: Notice = {
      ...newNoticeData,
      id: 'not-' + Date.now(),
    };
    setNotices([newNotice, ...notices]);
    showToast('Notice broadcasted to all residents! (அறிவிப்பு வெளியிடப்பட்டது)');
  };

  const handleSelectComplaintDetail = (complaint: Complaint) => {
    setSelectedComplaint(complaint);
    setActiveView('complaint_detail');
  };

  // If user is not logged in, display login screen
  if (!currentUser || activeView === 'login') {
    return <LoginScreen onLoginSuccess={handleLoginSuccess} />;
  }

  // Header Title derivation
  const getHeaderTitle = () => {
    if (activeView === 'notices' || activeTab === 'notices') {
      return 'Notices';
    }
    if (activeView === 'committee_dashboard' || currentUser.role === 'committee') {
      return 'Committee Dashboard';
    }
    return 'Resident Complaints';
  };

  const renderContent = () => {
    if (activeView === 'raise_complaint' || activeTab === 'raise') {
      return (
        <RaiseComplaintScreen
          currentUser={currentUser}
          onBack={() => {
            setActiveTab('complaints');
            setActiveView(currentUser.role === 'committee' ? 'committee_dashboard' : 'resident_home');
          }}
          onSubmit={handleCreateComplaint}
        />
      );
    }

    if (activeView === 'complaint_detail' && selectedComplaint) {
      return (
        <ComplaintDetailScreen
          complaint={selectedComplaint}
          currentUser={currentUser}
          onBack={() => {
            setActiveTab('complaints');
            setActiveView(currentUser.role === 'committee' ? 'committee_dashboard' : 'resident_home');
          }}
          onUpdateComplaint={handleUpdateComplaint}
        />
      );
    }

    if (activeView === 'notices' || activeTab === 'notices') {
      return (
        <>
          <TopHeader
            title="Notices"
            currentUser={currentUser}
            onSwitchRole={handleSwitchRole}
            onLogout={handleLogout}
            onUpdateUser={setCurrentUser}
          />
          <NoticesScreen
            notices={notices}
            currentUser={currentUser}
            onAddNotice={handleAddNotice}
          />
        </>
      );
    }

    if (currentUser.role === 'committee' || activeView === 'committee_dashboard') {
      return (
        <>
          <TopHeader
            title="Committee Dashboard"
            currentUser={currentUser}
            onSwitchRole={handleSwitchRole}
            onLogout={handleLogout}
            onUpdateUser={setCurrentUser}
          />
          <CommitteeDashboardScreen
            complaints={complaints}
            onSelectComplaint={handleSelectComplaintDetail}
          />
        </>
      );
    }

    // Default Resident Home Screen
    return (
      <>
        <TopHeader
          title="Resident Complaints"
          currentUser={currentUser}
          onSwitchRole={handleSwitchRole}
          onLogout={handleLogout}
          onUpdateUser={setCurrentUser}
        />
        <ResidentHomeScreen
          complaints={complaints}
          currentUser={currentUser}
          onRaiseClick={() => {
            setActiveTab('raise');
            setActiveView('raise_complaint');
          }}
          onSelectComplaint={handleSelectComplaintDetail}
        />
      </>
    );
  };

  const isNavVisible =
    activeView !== 'raise_complaint' && activeView !== 'complaint_detail';

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-0 sm:p-4">
      {/* Top Demo Bar for Reviewing Screens */}
      <div className="w-full max-w-md hidden sm:flex items-center justify-between py-2 px-3 mb-2 bg-slate-800/90 backdrop-blur rounded-2xl border border-slate-700 text-xs text-slate-300 shadow">
        <div className="flex items-center gap-2 font-bold text-teal-300">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          Colony Connect Portal
        </div>

        {/* Screen Quick switcher */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => handleSwitchRole(currentUser.role === 'resident' ? 'committee' : 'resident')}
            className="px-2.5 py-1 bg-slate-700 hover:bg-slate-600 rounded-lg text-white font-semibold transition"
          >
            Role: <span className="text-teal-300 font-bold">{currentUser.role === 'resident' ? 'Resident' : 'Committee'}</span>
          </button>
          <button
            onClick={() => handleLogout()}
            className="px-2 py-1 bg-slate-700/60 hover:bg-slate-700 rounded-lg text-slate-400 hover:text-white"
            title="Go to Login screen"
          >
            Login Screen
          </button>
        </div>
      </div>

      {/* Main Container - replicates the mobile viewport perfectly while responsive */}
      <main
        className={`w-full ${
          isMobileFrameView ? 'max-w-md' : 'max-w-xl'
        } bg-[#F4F7F6] min-h-screen sm:min-h-[850px] sm:max-h-[920px] sm:rounded-[36px] sm:shadow-2xl sm:border-[8px] sm:border-slate-800 relative overflow-y-auto overflow-x-hidden flex flex-col`}
      >
        {renderContent()}

        {/* Bottom Navigation */}
        {isNavVisible && (
          <BottomNavBar activeTab={activeTab} onSelectTab={handleSelectTab} />
        )}

        {/* Global Toast Notification */}
        {toastMessage && (
          <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 max-w-sm w-11/12 bg-slate-900/95 text-white px-4 py-3 rounded-2xl shadow-xl border border-slate-700 flex items-center gap-2 text-xs font-semibold animate-in fade-in slide-in-from-top-4 duration-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span className="flex-1 leading-tight">{toastMessage}</span>
          </div>
        )}
      </main>
    </div>
  );
}
